# pip install Flask
# python app.py
# http://127.0.0.1:5000/
# http://127.0.0.1:5000/contacto
# http://127.0.0.1:5000/saludo
# http://127.0.0.1:5000/info

from flask import Flask, render_template, jsonify

app = Flask(__name__)

@app.route('/')
def principal():
    return render_template('principal.html')

@app.route('/contactos')
def contactos():
    return render_template('contactos.html')

@app.route('/info', methods=['GET'])
def obtener_info():
    return jsonify([{'nombre': 'Federico Rico'},{'nombre': 'Pedro'}])

if __name__ == '__main__':
    app.run(debug=True)